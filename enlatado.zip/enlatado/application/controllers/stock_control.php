<?php

defined('BASEPATH') or exit('No direct script access allowed');

class stock_control extends CI_Controller
{
  public function back()
  {
    $this->load->view("main_view");
  }
}