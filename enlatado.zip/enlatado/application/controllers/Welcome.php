<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('login_view');
	}

	public function login()
	{

		$us = $this -> input -> post("username");
		$pa = $this -> input -> post("password");
		$em = $this -> input -> post("email");

		$datos = array(
			"user" => $us,
			"pass" => $pa,
			"email" => $em
		);
		
		$this -> session -> set_userdata($datos);

		if ($us == "facucarrion" and $pa == "password")
		{
			$this -> load -> view ("main_view", compact("datos"));
		}
		else
		{
			$this -> load -> view ("login_view");
		}
		
	}

}