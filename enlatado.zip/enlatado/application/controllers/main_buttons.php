<?php

defined('BASEPATH') or exit('No direct script access allowed');

class main_buttons extends CI_Controller
{

  public function provideer()
  {
    $this->load->view('provideers_view');
  }

  public function clients()
  {

    $this->load->view('abm-client_view');
  }

  public function communication()
  {
    $this->load->view('communication_view');
  }

  public function stock()
  {
    $this->load->view('stock_view');
  }

  public function sale()
  {
    $this->load->view('sale_view');
  }
}
