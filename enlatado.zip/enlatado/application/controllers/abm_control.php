<?php

defined('BASEPATH') or exit('No direct script access allowed');

class abm_control extends CI_Controller
{

  public function back()
  {
    $this->load->view("main_view");
  }

  public function alldata()
  {
    $this->load->view("abm-client_alldata_view");
  }

  public function create()
  {

    $data = array(

      // Personal Data Variables
      "legalentity" => $this->input->post("legalentity"),
      "companyname" => $this->input->post("companyname"),
      "firstsurname" => $this->input->post("firstsurname"),
      "secondsurname" => $this->input->post("secondsurname"),
      "gender" => $this->input->post("gender"),
      "documentype" => $this->input->post("documentype"),
      "document" => $this->input->post("document"),
      "birthdate" => $this->input->post("day") . "/" . $this->input->post("month") . "/" . $this->input->post("year"),
      /**/

      // Adresses Variables
      "street" => $this->input->post("street"),
      "number" => $this->input->post("number"),
      "state" => $this->input->post("state"),
      "city" => $this->input->post("city"),
      "postalcode" => $this->input->post("postalcode"),
      /**/

      // Contact Variables
      "email" => $this->input->post("email"),
      "phonenumber" => $this->input->post("phonenumber"),
      /**/

      // Notes Variable
      "notes" => $this->input->post("notes"),
      /**/

      // Readonly Variable
      "creationdate" => $this->input->post("creationdate"),
      "id" => $this->input->post("id")
      /**/

    );

    $linea = $data["id"] . "," . $data["legalentity"] . "," . $data["companyname"] . "," . $data["firstsurname"] . "," . $data["secondsurname"] . "," . $data["gender"] . "," . $data["documentype"] . "," . $data["document"] . "," . $data["birthdate"] . "," . $data["street"] . "," . $data["number"] . "," . $data["state"] . "," . $data["city"] . "," . $data["postalcode"] . "," . $data["email"] . "," . $data["phonenumber"] . "," . $data["notes"] . "," . $data["creationdate"] . '&' . "\r\n";

    $url = $_SERVER["DOCUMENT_ROOT"] . '/enlatado/data/datos.txt';

    $archivo = fopen($url, 'a') or die("can't open file");

    fwrite($archivo, $linea);

    fclose($archivo);

    redirect("main_buttons/clients");
  }

  public function remove()
  {

    $receivedata = array(

      "id" => $this->input->get("id"),
      "legalentity" => $this->input->get("legalentity"),
      "document" => $this->input->get("document")

    );

    $url = $_SERVER["DOCUMENT_ROOT"] . '/enlatado/data/datos.txt';
    $filestream = fopen($url, 'r') or die("can't open file");

    $file = file($url);

    fclose($filestream);

    $qregisters = sizeOf($file);

    $overwrite = "";

    for ($i = 0; $i < $qregisters; $i++) {

      $explodedata = explode(',', $file[$i]);

      if ($explodedata[0] == $receivedata["id"] && $explodedata[7] == $receivedata["document"]) {
      } else {
        $overwrite = $overwrite . $file[$i];
      }
    }

    $filestream = fopen($url, 'w');


    fwrite($filestream, $overwrite);


    fclose($filestream);

    redirect("main_buttons/clients");
  }

  public function modify_getdata()
  {

    $receivedata = array(

      "id" => $this->input->get("id"),
      "legalentity" => $this->input->get("legalentity"),
      "document" => $this->input->get("document")

    );

    $url = $_SERVER["DOCUMENT_ROOT"] . '/enlatado/data/datos.txt';
    $filestream = fopen($url, 'r') or die("can't open file");

    $filecontent = file_get_contents($url);

    $registers = explode("&", $filecontent);

    $qregisters = sizeOf($registers);

    for ($i = 0; $i < $qregisters - 1; $i++) {

      $explodedata = explode(",", $registers[$i]);

      if ($explodedata[0] == $receivedata["id"] && $explodedata[7] == $receivedata["document"]) {

        $tomodifyregister = $i;
      }
    }

    $tomodifydata_index = explode(",", $registers[$tomodifyregister]);
    $tomodifydatexploded = explode("/", $tomodifydata_index[8]);

    $tomodifydata = array(

      // Personal Data Variables
      "legalentity" => $tomodifydata_index[1],
      "companyname" => $tomodifydata_index[2],
      "firstsurname" => $tomodifydata_index[3],
      "secondsurname" => $tomodifydata_index[4],
      "gender" => $tomodifydata_index[5],
      "documentype" => $tomodifydata_index[6],
      "document" => $tomodifydata_index[7],
      "birthdateDay" => $tomodifydatexploded[0],
      "birthdateMonth" => $tomodifydatexploded[1],
      "birthdateYear" => $tomodifydatexploded[2],
      /**/

      // Adresses Variables
      "street" => $tomodifydata_index[9],
      "number" => $tomodifydata_index[10],
      "state" => $tomodifydata_index[11],
      "city" => $tomodifydata_index[12],
      "postalcode" => $tomodifydata_index[13],
      /**/

      // Contact Variables
      "email" => $tomodifydata_index[14],
      "phonenumber" => $tomodifydata_index[15],
      /**/

      // Notes Variable
      "notes" => $tomodifydata_index[16],
      /**/

      // Readonly Variable
      "creationdate" => $tomodifydata_index[17],
      "id" => $tomodifydata_index[0],
      /**/

      // Register Pointer
      "i" => $tomodifyregister
      /**/
    );


    $this->load->view("abm-client_view_modify", compact("tomodifydata"));
  }

  public function modify_newdata()
  {
    $index = $this->input->get("i");

    $data = array(

      // Id Variable
      "id" => $this->input->post("id"),

      // Personal Data Variables
      "legalentity" => $this->input->post("legalentity"),
      "companyname" => $this->input->post("companyname"),
      "firstsurname" => $this->input->post("firstsurname"),
      "secondsurname" => $this->input->post("secondsurname"),
      "gender" => $this->input->post("gender"),
      "documentype" => $this->input->post("documentype"),
      "document" => $this->input->post("document"),
      "birthdate" => $this->input->post("day") . "/" . $this->input->post("month") . "/" . $this->input->post("year"),

      // Adresses Variables
      "street" => $this->input->post("street"),
      "number" => $this->input->post("number"),
      "state" => $this->input->post("state"),
      "city" => $this->input->post("city"),
      "postalcode" => $this->input->post("postalcode"),

      // Contact Variables
      "email" => $this->input->post("email"),
      "phonenumber" => $this->input->post("phonenumber"),

      // Notes Variable
      "notes" => $this->input->post("notes"),

      // Readonly Variable
      "creationdate" => $this->input->post("creationdate")

    );

    $line = implode(",", $data) . "&" . "\r\n";

    $url = $_SERVER["DOCUMENT_ROOT"] . '/enlatado/data/datos.txt';

    $file = file($url);

    $qregisters = sizeOf($file);

    $overwrite = "";

    for ($i = 0; $i < $qregisters; $i++) {
      $explodedata = explode(",", $file[$i]);

      if ($explodedata[0] == $data["id"]) {
        $overwrite = $overwrite . $line;
      } else {
        $overwrite = $overwrite . $file[$i];
      }
    }

    $filestream = fopen($url, "w");

    fwrite($filestream, $overwrite);

    fclose($filestream);

    redirect("main_buttons/clients");
  }
}
