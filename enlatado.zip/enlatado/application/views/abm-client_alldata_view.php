<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href=<?php echo base_url("assets/styles/normalize.css") ?>>
  <?php date_default_timezone_set('America/Argentina/Buenos_Aires'); ?>

  <title>ABM Clients Modify</title>
  <link rel="shortcut icon" href=<?php echo base_url("assets/img/logo.ico") ?> type="image/x-icon">

  <style type="text/css">
    * {
      padding: 0;
      margin: 0;
      box-sizing: border-box;
    }

    @font-face {
      font-family: Montserrat;
      src: url(<?php echo base_url("assets/font/Montserrat-VariableFont_wght.ttf") ?>);
    }

    body {
      background-color: #efefef;
      font-family: Montserrat;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='105' viewBox='0 0 80 105'%3E%3Cg fill-rule='evenodd'%3E%3Cg id='death-star' fill='%239d9d9d' fill-opacity='0.09'%3E%3Cpath d='M20 10a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V10zm15 35a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zM20 75a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V75zm30-65a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V10zm0 65a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V75zM35 10a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10zM5 45a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zm0-35a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10zm60 35a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zm0-35a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
      display: flex;
      height: 100vh;
      width: 100vw;
      overflow: hidden;
    }

    .container {
      background-color: white;
      position: relative;
      width: 90vw;
      height: 80vh;
      margin: auto;
      border-radius: 3px;
      box-shadow: 0px 0px 7px #737373;
      display: flex;
      flex-direction: column;
    }

    .img-link {
      position: relative;
      border-radius: 10px;
      margin-left: 1em;
      text-decoration: none;
    }

    .back-img {
      height: 35px;
      width: 35px;
      background-color: transparent;
      border-radius: 20%;

    }

    .back-img:hover {
      opacity: .7;
    }

    .container__nav {
      height: 3.5em;
      width: 90vw;
      background-color: #c7c7c7;
      border-bottom: 1px solid rgba(77, 77, 77, 0.25);
      display: flex;
      flex-direction: row;
      align-items: center;
      gap: 1.5em;

    }

    .container__table {
      position: relative;
      display: flex;
      flex-direction: column;
      flex-wrap: nowrap;
      width: 90vw;
      height: 100%;
      overflow-y: scroll;
    }

    .container__table--text {
      font-size: 1.25em;
      width: auto;
      height: 12vh;
      display: flex;
      padding: 0 2em;
      position: relative;
      align-items: center;
      vertical-align: middle;
    }

    .container__table--article {
      height: 12vh;
      background-color: #fafafa;
      border: 1px solid #737373;
      border-top: none;
      top: -1px;
      display: flex;
      padding: 2em 1em;
      gap: 2px;
    }

    .container__table--nav {
      background-color: #efefef;
      top: 0;
      padding: 2em 1em;
      height: 15vh;
      z-index: 100;
      position: sticky;
      display: flex;
      align-items: center;
      color: #efefef;
      background-color: #c7c7c7;
    }
  </style>
</head>

<body>
  <section class="container">
    <nav class="container__nav">
      <a href=<?php echo base_url("index.php/main_buttons/clients") ?> class="img-link"><img src=<?php echo base_url("assets/img/back-icon.png") ?> alt="back" class="back-img"></a>
      <h2>
        All-Data View
      </h2>
    </nav>
    <section class="container__table">
      <nav class="container__table--nav">
        <span class="container__table--text">
          ID | Legal Entity | Company Name | First Surname | Second Surname | Gender | Documentype | Document | Birthdate | Street | Number | State | City | Postal Code | E-Mail | Phone Number | Notes | Creation Date
        </span>
      </nav>
      <?php
      $url = $_SERVER["DOCUMENT_ROOT"] . '/enlatado/data/datos.txt';
      $filestream = fopen($url, 'r') or die("can't open file");

      $filecontent = file_get_contents($url);
      $filecontent = str_replace("\r\n", "", $filecontent);
      $filecontent = str_replace(",", " | ", $filecontent);

      $registers = explode("&", $filecontent);
      $qregisters = sizeOf($registers) - 1;

      for ($i = 0; $i < $qregisters; $i++) {

        echo
        '<article class="container__table--article container__table--text">' .
          $registers[$i] .
          '</article>';
      }

      ?>
    </section>
  </section>
</body>

</html>