<!DOCTYPE html>
<html lang="en">

<head>

  <!-- Metadata -->

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href=<?php echo base_url("assets/styles/normalize.css") ?>>
  <?php date_default_timezone_set('America/Argentina/Buenos_Aires'); ?>

  <!---->

  <!-- Tab Style -->

  <title>ABM Clients Modify</title>
  <link rel="shortcut icon" href=<?php echo base_url("assets/img/logo.ico") ?> type="image/x-icon">

  <!---->

  <!-- Veryfication Methods-->

  <?php

  function VerifyDocumentype($type, $dni)
  {
    if ($dni == $type) {
      echo ' selected="true"';
    } else {
    }
  }

  function VerifyDateofbirth($thing, $value, $date)
  {

    if ($thing == "day") {

      if ($value == $date) {

        echo ' selected="true"';
      }
    }

    if ($thing == "month") {

      if ($value == $date) {

        echo ' selected="true"';
      }
    }
  }

  ?>
  <!---->

  <style type="text/css">
    /* Estilos Globales */

    @font-face {
      font-family: Montserrat;
      src: url(<?php echo base_url("assets/font/Montserrat-VariableFont_wght.ttf") ?>)
    }

    body {
      background-color: #efefef;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='105' viewBox='0 0 80 105'%3E%3Cg fill-rule='evenodd'%3E%3Cg id='death-star' fill='%239d9d9d' fill-opacity='0.09'%3E%3Cpath d='M20 10a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V10zm15 35a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zM20 75a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V75zm30-65a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V10zm0 65a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V75zM35 10a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10zM5 45a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zm0-35a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10zm60 35a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zm0-35a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
      display: flex;
      height: 100vh;
      width: 100vw;
      font-family: Montserrat;
    }

    /**/

    /* Estilos de la Ventana */

    .container {
      background-color: white;
      position: relative;
      width: 90vw;
      height: 90vh;
      border-radius: 3px;
      margin: auto;
      box-shadow: 0px 0px 7px #737373;
      display: grid;
      grid-template-columns: 1fr 4fr;
      grid-template-areas: "aside form";
    }

    /**/

    /* Estilos del Aside */

    .container-aside {
      background-color: #dedede;
      border-right: 1px solid rgba(77, 77, 77, 0.25);
      display: flex;
      padding: 10px;
      width: auto;
      flex-direction: column;
      justify-content: center;
    }

    .img-link {
      position: absolute;
      border-radius: 10px;
      top: .5em;
      left: .5em
    }

    .back-img {
      height: 35px;
      width: 35px;
      background-color: transparent;
      border-radius: 20%;
      border: 4px solid rgba(77, 77, 77, 0.5);
    }

    .back-img:hover {
      opacity: .7;
    }

    .abm-buttons {
      text-decoration: none;
      box-sizing: border-box;
      color: black;
      font-family: Montserrat;
      padding: .5em;
      background-color: #efefef;
      position: relative;
      text-align: center;
      border: none
    }

    .abm-buttons {
      transition: all 0.5s;
      -webkit-transition: all 0.5s;
      -moz-transition: all 0.5s;
    }

    .abm-buttons:hover {
      opacity: .8;
      zoom: 1.05;
    }


    /**/

    /* Estilos de Formulario */

    .a-form {
      grid-area: form;
      padding: 1em;
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      grid-template-rows: repeat(6, 1fr);
      grid-template-areas:
        "data direction contact"
        "data direction contact"
        "data direction contact"
        "data notes notes"
        "data notes notes"
        "data readonly btn";
      gap: .75em
    }

    /**/

    /* Estilos de Fieldset Data */

    .a-form_data {
      grid-area: data;
      padding: .5em;
      display: inline-flex;
      flex-direction: column;
      justify-content: space-between;
      outline: 3px solid #c7c7c7;
    }

    .form__data--label {
      width: 100%;
      display: flex;
      flex-direction: column
    }

    .input-input {
      display: flex;
      position: relative;
      width: 97%;
      height: .8em;
      margin-top: .25em
    }

    .input-input:focus {
      outline: none;
    }

    .input-input:active {
      outline: none;
    }

    .input {
      position: relative;
      width: 100%;
      padding: 0
    }

    .form__data--selection {
      display: flex
    }

    .form__data--radio {
      display: flex;
    }

    /**/

    /* Estilos de Fieldset Direction */

    .a-form_direction {
      grid-area: direction;
      padding: .5em;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      outline: 3px solid #c7c7c7
    }

    .label-input_adresses {
      position: relative;
      width: 100%
    }

    .input_adresses {
      position: relative;
      width: 97%;

    }

    /**/

    /* Estilos de Fieldset Contact */

    .a-form_contact {
      grid-area: contact;
      padding: .5em;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
      outline: 3px solid #c7c7c7;
      gap: 1em
    }

    .form__contact--label {
      position: relative;
      width: 100%
    }

    /**/

    /* Notes Fieldset Style */

    .a-form_notes {
      grid-area: notes;
      padding: 1em .5em;
      display: flex;
      outline: 3px solid #c7c7c7;
      flex-direction: column;
      justify-content: space-between
    }

    .form__notes--input {
      position: relative;
      height: 80%;
      resize: none;
      padding: .15em
    }


    .form__notes--legend {
      display: inline
    }

    /**/

    /* Buttons Section Style */

    .a-form_buttons {
      grid-area: btn;
      padding: 1.5em 0;
      display: flex;
      flex-direction: row-reverse;
      align-items: bottom
    }

    .a-form_buttons .abm-buttons {
      background-color: #c7c7c7;
      float: right;
      padding: .2em 2em;
    }

    /**/

    /* Read-Only Section Style */
    .a-form_readonly {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: .75em;
    }

    .a-form_readonly-date,
    .a-form_readonly-id {
      outline: 3px solid #c7c7c7;
      padding: .5em;
      display: flex;
      flex-direction: column;
      justify-content: space-around
    }

    .form__readonly--id_input,
    .form__readonly--date_input {
      position: relative;
      width: 75%;
    }

    /**/
  </style>

</head>

<body>

  <section class="container">

    <aside class="container-aside">

      <span class="container-aside--header">

        <a href=<?php echo base_url("index.php/main_buttons/clients") ?> class="img-link"><img src=<?php echo base_url("assets/img/back-icon.png") ?> alt="back" class="back-img"></a>

        <h2>

          Modifying <?php echo $tomodifydata['legalentity']; ?>

        </h2>

      </span>

    </aside>

    <form class="a-form" method="post" action=<?php echo base_url("index.php/abm_control/modify_newdata") . "?i=" . $tomodifydata["i"] ?>>

      <section class="a-form_data">

        <label for="legalentity" class="form__data--label">Legal Entity:

          <input type="text" name="legalentity" value="<?php echo $tomodifydata['legalentity']; ?>" class="input-input" required>

        </label>

        <label for="companyname" class="form__data--label">Company Name:

          <input type="text" name="companyname" value="<?php echo $tomodifydata['companyname']; ?>" class="input-input">

        </label>

        <label for="firstsurname" class="form__data--label">First Surname:

          <input type="text" name="firstsurname" value="<?php echo $tomodifydata['firstsurname']; ?>" class="input-input">

        </label>

        <label for="secondsurname" class="form__data--label">Second Surname:

          <input type="text" name="secondsurname" value="<?php echo $tomodifydata['secondsurname']; ?>" class="input-input">

        </label>

        <label for="gender" class="form__data--label">Gender:

          <fatherinput class="form__data--fatherinput">

            <input type="radio" name="gender" value="Male" <?php
                                                            if ($tomodifydata['gender'] == "Male") {
                                                              echo ' checked';
                                                            }
                                                            ?>> Male

            <input type="radio" name="gender" value="Female" <?php
                                                              if ($tomodifydata['gender'] == "Female") {
                                                                echo ' checked';
                                                              }
                                                              ?> style="margin-left:1em"> Female

          </fatherinput>

        </label>

        <label for="documentype" class="form__data--label">Document Type:

          <select name="documentype" style="position: relative; width: 173px" class="seleccion">

            <option value="DNI" <?php VerifyDocumentype("DNI", $tomodifydata["documentype"]); ?>>DNI</option>
            <option value="LC" <?php VerifyDocumentype("LC", $tomodifydata["documentype"]); ?>>LC</option>
            <option value="LE" <?php VerifyDocumentype("LE", $tomodifydata["documentype"]); ?>>LE</option>
            <option value="CI" <?php VerifyDocumentype("CI", $tomodifydata["documentype"]); ?>>CI</option>

          </select>

        </label>

        <label for="document" class="form__data--label">Document:

          <input type="text" maxlength="8" class="input-input" name="document" value="<?php echo $tomodifydata['document']; ?>" required>

        </label>

        <fatherinput>

          <label for="day" class="form__data--label">Date of Birth:</label>
          <selection class="form__data--selection">

            <select name="day" value="Dd" style="position: relative; width: 25%" class="seleccion">

              <option value="1" <?php VerifyDateofbirth("day", "1", $tomodifydata["birthdateDay"]); ?>>1</option>
              <option value="2" <?php VerifyDateofbirth("day", "2", $tomodifydata["birthdateDay"]); ?>>2</option>
              <option value="3" <?php VerifyDateofbirth("day", "3", $tomodifydata["birthdateDay"]); ?>>3</option>
              <option value="4" <?php VerifyDateofbirth("day", "4", $tomodifydata["birthdateDay"]); ?>>4</option>
              <option value="5" <?php VerifyDateofbirth("day", "5", $tomodifydata["birthdateDay"]); ?>>5</option>
              <option value="6" <?php VerifyDateofbirth("day", "6", $tomodifydata["birthdateDay"]); ?>>6</option>
              <option value="7" <?php VerifyDateofbirth("day", "7", $tomodifydata["birthdateDay"]); ?>>7</option>
              <option value="8" <?php VerifyDateofbirth("day", "8", $tomodifydata["birthdateDay"]); ?>>8</option>
              <option value="9" <?php VerifyDateofbirth("day", "9", $tomodifydata["birthdateDay"]); ?>>9</option>
              <option value="10" <?php VerifyDateofbirth("day", "10", $tomodifydata["birthdateDay"]); ?>>10</option>
              <option value="11" <?php VerifyDateofbirth("day", "11", $tomodifydata["birthdateDay"]); ?>>11</option>
              <option value="12" <?php VerifyDateofbirth("day", "12", $tomodifydata["birthdateDay"]); ?>>12</option>
              <option value="13" <?php VerifyDateofbirth("day", "13", $tomodifydata["birthdateDay"]); ?>>13</option>
              <option value="14" <?php VerifyDateofbirth("day", "14", $tomodifydata["birthdateDay"]); ?>>14</option>
              <option value="15" <?php VerifyDateofbirth("day", "15", $tomodifydata["birthdateDay"]); ?>>15</option>
              <option value="16" <?php VerifyDateofbirth("day", "16", $tomodifydata["birthdateDay"]); ?>>16</option>
              <option value="17" <?php VerifyDateofbirth("day", "17", $tomodifydata["birthdateDay"]); ?>>17</option>
              <option value="18" <?php VerifyDateofbirth("day", "18", $tomodifydata["birthdateDay"]); ?>>18</option>
              <option value="19" <?php VerifyDateofbirth("day", "19", $tomodifydata["birthdateDay"]); ?>>19</option>
              <option value="20" <?php VerifyDateofbirth("day", "20", $tomodifydata["birthdateDay"]); ?>>20</option>
              <option value="21" <?php VerifyDateofbirth("day", "21", $tomodifydata["birthdateDay"]); ?>>21</option>
              <option value="22" <?php VerifyDateofbirth("day", "22", $tomodifydata["birthdateDay"]); ?>>22</option>
              <option value="23" <?php VerifyDateofbirth("day", "23", $tomodifydata["birthdateDay"]); ?>>23</option>
              <option value="24" <?php VerifyDateofbirth("day", "24", $tomodifydata["birthdateDay"]); ?>>24</option>
              <option value="25" <?php VerifyDateofbirth("day", "25", $tomodifydata["birthdateDay"]); ?>>25</option>
              <option value="26" <?php VerifyDateofbirth("day", "26", $tomodifydata["birthdateDay"]); ?>>26</option>
              <option value="27" <?php VerifyDateofbirth("day", "27", $tomodifydata["birthdateDay"]); ?>>27</option>
              <option value="28" <?php VerifyDateofbirth("day", "28", $tomodifydata["birthdateDay"]); ?>>28</option>
              <option value="29" <?php VerifyDateofbirth("day", "29", $tomodifydata["birthdateDay"]); ?>>29</option>
              <option value="30" <?php VerifyDateofbirth("day", "30", $tomodifydata["birthdateDay"]); ?>>30</option>
              <option value="31" <?php VerifyDateofbirth("day", "31", $tomodifydata["birthdateDay"]); ?>>31</option>

            </select>

            <select name="month" value="Mm" style="position:relative; width: 35%" class="seleccion">

              <option value="01" <?php VerifyDateofbirth("month", "01", $tomodifydata["birthdateMonth"]); ?>>January</option>
              <option value="02" <?php VerifyDateofbirth("month", "02", $tomodifydata["birthdateMonth"]); ?>>February</option>
              <option value="03" <?php VerifyDateofbirth("month", "03", $tomodifydata["birthdateMonth"]); ?>>March</option>
              <option value="04" <?php VerifyDateofbirth("month", "04", $tomodifydata["birthdateMonth"]); ?>>April</option>
              <option value="05" <?php VerifyDateofbirth("month", "05", $tomodifydata["birthdateMonth"]); ?>>May</option>
              <option value="06" <?php VerifyDateofbirth("month", "06", $tomodifydata["birthdateMonth"]); ?>>June</option>
              <option value="07" <?php VerifyDateofbirth("month", "07", $tomodifydata["birthdateMonth"]); ?>>July</option>
              <option value="08" <?php VerifyDateofbirth("month", "08", $tomodifydata["birthdateMonth"]); ?>>August</option>
              <option value="09" <?php VerifyDateofbirth("month", "09", $tomodifydata["birthdateMonth"]); ?>>September</option>
              <option value="10" <?php VerifyDateofbirth("month", "10", $tomodifydata["birthdateMonth"]); ?>>October</option>
              <option value="11" <?php VerifyDateofbirth("month", "11", $tomodifydata["birthdateMonth"]); ?>>November</option>
              <option value="12" <?php VerifyDateofbirth("month", "12", $tomodifydata["birthdateMonth"]); ?>>December</option>

            </select>

            <input type="number" value=<?php

                                        echo $tomodifydata["birthdateYear"];

                                        ?> step="1" style="position:relative; width: 35%" class="seleccion" name="year">

          </selection>

        </fatherinput>

      </section>

      <section class="a-form_direction">

        <label for="street" class="label-input_adresses street">Street:

          <input type="text" name="street" class="input-input" value="<?php echo $tomodifydata['street']; ?>">

        </label>

        <label for="number" class="label-input_adresses number">Number:

          <input type="text" name="number" class="input-input" value="<?php echo $tomodifydata['number']; ?>">

        </label>

        <label for="state" class="label-input_adresses state">State:

          <input type="text" name="state" class="input-input" value="<?php echo $tomodifydata['state']; ?>">

        </label>

        <label for="city" class="label-input_adresses city">City:

          <input type="text" name="city" class="input-input" value="<?php echo $tomodifydata['city']; ?>">

        </label>

        <label for="postalcode" class="label-input_adresses postalcode">Postal Code:

          <input type="number" name="postalcode" min="0" max="99999999" class="input-input" value="<?php echo $tomodifydata['postalcode']; ?>">

        </label>

      </section>

      <section class="a-form_contact">

        <label for="email" class="form__contact--label">E-Mail:

          <input type="text" name="email" class="input-input" value="<?php echo $tomodifydata['email']; ?>">

        </label>


        <label for="phonenumber" class="form__contact--label phonenumber">Phone Number:

          <input type="text" name="phonenumber" class="input-input" value="<?php echo $tomodifydata['phonenumber']; ?>">

        </label>

      </section>

      <section class="a-form_notes">

        <legend class="form__notes--legend">Notes (No commas neither jumps):</legend>
        <textarea type="text" class="input-input form__notes--input" name="notes"><?php echo $tomodifydata['notes']; ?></textarea>

      </section>

      <section class="a-form_readonly">

        <section class="a-form_readonly-date">

          <label for="creationdate">Creation Date: </label>
          <input name="creationdate" value="<?php echo $tomodifydata['creationdate']; ?>" class="input-input form__readonly--date_input" readonly>

        </section>

        <section class="a-form_readonly-id">

          <label for="id">Client ID: </label>
          <input name="id" class="input-input form__readonly--id_input" readonly value="<?php echo $tomodifydata['id']; ?>">

        </section>

      </section>

      <section class="a-form_buttons">

        <input type="submit" value="Modify" class="abm-buttons">

      </section>

    </form>

  </section>

</body>

</html>