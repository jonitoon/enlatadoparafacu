<!DOCTYPE html>
<html lang="en">

<head>

  <!-- Metadata -->

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href=<?php echo base_url("assets/styles/normalize.css") ?>>

  <!---->

  <!-- Tab Style -->

  <title>Log-In</title>
  <link rel="shortcut icon" href=<?php echo base_url("assets/img/logo.ico") ?> type="image/x-icon">

  <!---->

  <style type="text/css">
    /* Global Styles */

    @font-face {
      font-family: Montserrat;
      src: url(<?php echo base_url("assets/font/Montserrat-VariableFont_wght.ttf") ?>);
    }

    body {
      background-color: #efefef;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='105' viewBox='0 0 80 105'%3E%3Cg fill-rule='evenodd'%3E%3Cg id='death-star' fill='%239d9d9d' fill-opacity='0.09'%3E%3Cpath d='M20 10a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V10zm15 35a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zM20 75a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V75zm30-65a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V10zm0 65a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V75zM35 10a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10zM5 45a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zm0-35a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10zm60 35a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zm0-35a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E");

    }

    /**/

    /* Estilos del Container */

    div {
      display: block;
    }

    div input {
      float: right;
      font-family: Montserrat;
      border: .5px solid rgba(77, 77, 77, 0.5);
      border-radius: 3px;
      padding: 1px 2px
    }

    div input:active {
      outline: none;
    }

    div input:focus {
      outline: none;
    }

    form h2 {
      margin: 0px 0px 20px 0px;
      display: inline-block;
      font-family: Montserrat;
    }

    form {
      background-color: #fafafa;
      position: absolute;
      width: 30vw;
      height: auto;
      padding: 15px;
      border-radius: 3px;
      box-shadow: 0px 0px 7px #737373;
      top: 50%;
      left: 50%;
      margin-top: -100px;
      transform: translateX(-50%)
    }

    form label {
      font-family: Montserrat;
    }

    #submitt {
      padding: 8px;
      float: right;
      font-family: Montserrat;
      border: 0;
      border-radius: 5px
    }

    #submitt:hover {
      opacity: .7;
    }

    #title {
      position: relative;
      width: 100%
    }

    /**/
  </style>

</head>

<body>

  <form method="post" action=<?php echo base_url("index.php/welcome/login") ?>>

    <h2 id="title">Log In:</h2><br>

    <div class="form_input">

      <label for="username" class="form_label">Username: </label>
      <input autocomplete="off" type="text" name="username" class="userypass" style="width: 250px">

    </div><br>

    <div class="form_input">

      <label for="email" class="form_label">E-Mail: </label>
      <input autocomplete="off" type="text" name="email" class="userypass" style="width: 250px">

    </div><br>

    <div class="form_input">

      <label for="password" class="form_label">Password: </label>
      <input type="password" name="password" class="form_input" style="width: 250px">

    </div><br>

    <input type="submit" value="Access" id="submitt">

  </form>

</body>

</html>