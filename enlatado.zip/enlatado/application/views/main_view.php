<!DOCTYPE html>
<html lang="en">

<head>

  <!-- Metadata -->

  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href=<?php echo base_url("assets/styles/normalize.css") ?>>

  <!---->

  <!-- Tab Style -->

  <title>Main Menu</title>
  <link rel="shortcut icon" href=<?php echo base_url("assets/img/logo.ico") ?> type="image/x-icon">

  <!---->

  <style type="text/css">
    /* Global Style */

    @font-face {
      font-family: Montserrat;
      src: url(<?php echo base_url("assets/font/Montserrat-VariableFont_wght.ttf") ?>);
    }

    body {
      background-color: #efefef;
      display: flex;
      justify-content: center;
      place-items: center;
      vertical-align: middle;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='105' viewBox='0 0 80 105'%3E%3Cg fill-rule='evenodd'%3E%3Cg id='death-star' fill='%239d9d9d' fill-opacity='0.09'%3E%3Cpath d='M20 10a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V10zm15 35a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zM20 75a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V75zm30-65a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V10zm0 65a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V75zM35 10a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10zM5 45a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zm0-35a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10zm60 35a5 5 0 0 1 10 0v50a5 5 0 0 1-10 0V45zm0-35a5 5 0 0 1 10 0v20a5 5 0 0 1-10 0V10z' /%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
      width: 100vw;
      height: 100vh;
    }

    /**/

    /* Container Style */

    .container {
      background-color: white;
      position: relative;
      width: 80vw;
      height: 90vh;
      margin: auto;
      border-radius: 3px;
      box-shadow: 0px 0px 7px #737373
    }

    .container-title {
      position: relative;
      width: 50%;
      height: 35%;
      margin: auto;
      display: grid;
      justify-content: center;
      place-items: center;
      grid-template-columns: 1fr 1.5fr;
      grid-template-rows: 1fr 1fr;
      grid-template-areas:
        "img text"
        "img text";
    }

    /**/

    /* Container's Header Styles */

    .container-title h2 {
      font-family: Montserrat;
      display: inline;
      font-size: 2.4em;
      position: relative;
      justify-self: left;
      align-self: center;
      grid-area: text;
      bottom: .2em
    }

    .container-title img {
      position: relative;
      height: 10em;
      width: 10em;
      grid-area: img;
      justify-self: right
    }

    .container-title p {
      position: relative;
      font-family: Montserrat;
      font-size: 20px;
      justify-self: left;
      align-self: center;
      margin-left: 0.15em;
      grid-area: text;
      top: 1.1em
    }

    /**/

    /* Container's Button Pannel Styles */

    .container-button_panel {
      position: relative;
      width: 95%;
      height: 63%;
      margin: auto;
      display: grid;
      grid-template-rows: repeat(5, 1fr);
      gap: 1em;
    }

    .container-button_panel--btn {
      background-color: #efefef;
      padding: 1em auto;
      text-decoration: none;
      font-family: Montserrat;
      font-size: 25px;
      box-sizing: border-box;
      text-align: center;
      display: flex;
      align-items: center;
      justify-content: center;
      color: black;
      border-radius: 5px;
      opacity: 1;
    }

    .container-button_panel--btn {
      transition: all 0.5s;
    }

    .container-button_panel--btn:hover {
      opacity: .6;
      zoom: 1.1;
    }

    /**/
  </style>

</head>

<body>

  <section class="container">

    <div class="container-title">

      <img src=<?php echo base_url("assets/img/logo.png") ?> alt="logo" id="logoo">
      <h2>Facu Carrion</h2>
      <p>Hola, <?php echo $this->session->userdata("user") ?></p>

    </div>

    <div class="container-button_panel">

      <a href=<?php echo base_url("index.php/main_buttons/clients") ?> class="container-button_panel--btn">ABM Clients</a>
      <a href=<?php echo base_url("index.php/main_buttons/stock") ?> class="container-button_panel--btn">Stock List</a>
      <a href=<?php echo base_url("index.php/main_buttons/provideer") ?> class="container-button_panel--btn">Provideer List</a>
      <a href=<?php echo base_url("index.php/main_buttons/sale") ?> class="container-button_panel--btn">Sale Reports</a>
      <a href=<?php echo base_url("index.php/main_buttons/communication") ?> class="container-button_panel--btn">Communication</a>

    </div>

  </section>

</body>

</html>